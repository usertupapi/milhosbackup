package com.example.myproyect.actividades.clases;

public interface InterfaceMenu {
    public void onClickMenu(int idBoton);
}
